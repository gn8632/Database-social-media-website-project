package JavaFile;


public class NewUsers {

    public NewUsers(String emailaddress, String password) {
		super();
		Emailaddress = emailaddress;
		this.password = password;
	}
	public NewUsers(String emailaddress, String password, String firstName, String lastName, String gender,
			String dOB) {
		super();
		Emailaddress = emailaddress;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		DOB = dOB;
	}
    public NewUsers() {	
    }
    
	protected String Emailaddress;
    protected String password;
    protected String firstName;
    protected String lastName;
    protected String gender;
    protected String DOB;
    
	public String getEmailaddress() {
		return Emailaddress;
	}
	public void setEmailaddress(String emailaddress) {
		Emailaddress = emailaddress;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	
	 public String toString() {
		return (firstName+ "/"+lastName+"/"+ Emailaddress+"/"
				+DOB+"/"+gender);
	}

}

