package DAO;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;
import java.util.*;
import java.util.Map.Entry;

import JavaFile.NewUsers;

public class controllerDAO {
	Connection connect = null;
	PreparedStatement preaprestatement = null;
	Statement statement = null;
	ResultSet rs=null;
	private String url="jdbc:mysql://localhost:3306/website";
	private String name="root";
	private String pass="root";
	
	public void setFulldescription(String imageID, String email, String description) {
		String name = imageID +"/7/"+email+"/7/"+description;
		try {
		      FileWriter myWriter = new FileWriter("savedescription.txt");
		      myWriter.write(name);
		      myWriter.close();
		    } catch (IOException e) {
		      e.printStackTrace();
		    }
	}
	
	public String getFulldescription() {
		String data = null;
		try {
		      File myObj = new File("savedescription.txt");
		      Scanner myReader = new Scanner(myObj);
		      data = myReader.nextLine();
		      myReader.close();
		    } catch (FileNotFoundException e) {
		      e.printStackTrace();
		    }
		return data;
		
	}
//	NewUsers _user= new NewUsers();
	
	public controllerDAO(){
		
	}
	
	public boolean isUsernameExist(String username)throws SQLException {
	    connect_func();
		
		  statement=connect.createStatement();
		  rs=statement.executeQuery("SELECT email from website.users;");
		  String n="";
  		  while(rs.next()) {
  			n=rs.getString("email");
  	    	if(n.equals(username))
  	    		return true;
  	    }
  		  
		return false;
	}
	public boolean isItNewOrOldPicture(String email, int id) throws SQLException {
		 connect_func();
		
		 statement=connect.createStatement();
		
		String Q1 ="SELECT email, imageid FROM website.likeimage;";
		rs=statement.executeQuery(Q1);
		String n=email+id;
		String o="";
		boolean flag = false;
		while(rs.next()) {
			o=rs.getString(1)+rs.getString(2);
			if(n.equals(o)) {
				flag=true;
				break;
			}
		}		
		return flag;
		
	}
	public boolean isItMyImage(String email, int id) throws SQLException {
		 connect_func();
		
		 statement=connect.createStatement();
		
		String Q1 ="SELECT * FROM website.images;";
		rs=statement.executeQuery(Q1);
		String n=email+id;
		String o="";
		boolean flag = false;
		while(rs.next()) {
			o=rs.getString(4)+rs.getString(1);
			if(n.equals(o)) {
				flag=true;
				break;
			}
		}		
		return flag;

	}
	
	
	public int getLastImageID(String tableName) throws SQLException {
		connect_func(); 
		statement=connect.createStatement();
		String query ="select * from website."+tableName;	
		ResultSet rs =statement.executeQuery(query);
		int countRows = 0;
		while(rs.next()) {
			countRows++;
		}	
		return countRows ;		
	}
	
	public String getFirstAndLastName(String userEmail) throws SQLException {
		
		connect_func(); 
		statement=connect.createStatement();
		String query ="select * from website.users";	
		ResultSet rs =statement.executeQuery(query);
		
		while(rs.next()) {
			if(rs.getString(1).equals(userEmail))
				return rs.getString(3)+ " " +rs.getString(4);
		}	
			
		return "unknownUserName";
		
	}
	
	public String getTagName(int imgID) throws SQLException {
			
		connect_func(); 
		statement=connect.createStatement();
		String query ="select * from website.imagetag";	
		ResultSet rs =statement.executeQuery(query);
		
		while(rs.next()) {
			if(rs.getInt(1)==imgID)
				return rs.getNString(2);
		}				
		return "unknownImgTag";	
	}
	
	public void saveUsername(String name) {
		try {
		      FileWriter myWriter = new FileWriter("username.txt");
		      myWriter.write(name);
		      myWriter.close();
		    } catch (IOException e) {
		      e.printStackTrace();
		    }
	}
	
	public void saveAllinTextFile(int imageID, String tag, String email, String description) {
		String name = imageID +","+tag+","+email+","+description;
		try {
		      FileWriter myWriter = new FileWriter("save.txt");
		      myWriter.write(name);
		      myWriter.close();
		    } catch (IOException e) {
		      e.printStackTrace();
		    }
	}
	
	public String getAllfromSaveTxtfile() {
		String data = null;
		try {
		      File myObj = new File("save.txt");
		      Scanner myReader = new Scanner(myObj);
		      data = myReader.nextLine();
		      myReader.close();
		    } catch (FileNotFoundException e) {
		      e.printStackTrace();
		    }
		return data;
		
	}
	
	public String getUsername() {
		String data = null;
		try {
		      File myObj = new File("username.txt");
		      Scanner myReader = new Scanner(myObj);
		      data = myReader.nextLine();
		      myReader.close();
		    } catch (FileNotFoundException e) {
		      e.printStackTrace();
		    }
		return data;
		
	}
	

	public boolean isPasswordAndEmailCorrect(String Pass, String Email) throws SQLException {

		connect_func(); 
	    
	    statement=connect.createStatement();
	    rs=statement.executeQuery("SELECT email, password from website.users;");
	    String X=Pass+Email;
	    String PU="";
	    
	    while(rs.next()) {
	    	PU=rs.getString("email")+rs.getString("password");
	    	if(PU.equals(X))
	    		return true;
	    }
		return false;
		
	}
	
	public int getTotalLikorDislikeofImage(int LikeORdislikEcolumn , int imageid) throws SQLException {
		
		connect_func(); 
		String sql_q1="SELECT * FROM website.likeimage where imageid="+imageid+";";
		statement=connect.createStatement();
		ResultSet rs =statement.executeQuery(sql_q1);
		int counter = 0;
		while(rs.next()) {
			counter+=rs.getInt(LikeORdislikEcolumn);
		}		
		return counter;		
	}
	
	public ArrayList<String> getComment() throws SQLException {
		connect_func(); 
		ArrayList<String> cars = new ArrayList<String>();
		
		
		String sql_q1="SELECT * FROM website.comments;";
		statement=connect.createStatement();
		ResultSet rs =statement.executeQuery(sql_q1);

		String content="";
		
		while(rs.next()) {
			content=rs.getString(2) +"/7/"+rs.getString(1)+"/7/"+rs.getString(3);
			cars.add(content);
		}
		return cars;
		
	}
	public void registerAccount(NewUsers _user) throws SQLException {
		connect_func();
		String insert_into_user_table ="insert into  website.USERS(email,password, firstname,"
				+ "lastname,gender,birthday,numoffollowers,numoffollowing)"
				+ " values (?, ?, ?, ?, ?,?,?,?); " ;
	
		preaprestatement = connect.prepareStatement(insert_into_user_table);
	    
	    preaprestatement.setString(1,_user.getEmailaddress());
	    preaprestatement.setString(2,_user.getPassword());
	    preaprestatement.setString(3,_user.getFirstName());
	    preaprestatement.setString(4,_user.getLastName());
	    preaprestatement.setString(5,_user.getGender());
	    preaprestatement.setString(6,_user.getDOB()); 
	    preaprestatement.setInt(7, 0);
	    preaprestatement.setInt(8, 0);
	    
	    preaprestatement.execute();
	    
	    connect.close();
		
	}
	
	public boolean isFollowing(String following) throws SQLException {	
		connect_func();
		String Q="SELECT * FROM website.follow where followeremail='"+getUsername()+"';";
		statement=connect.createStatement();
	    rs=statement.executeQuery(Q);
	    while(rs.next()) {
	    	if(rs.getString(1).equals(following))
	    		return true;
	    }
		
		return false;	
	}
	
	
	public ArrayList<String> getFollowers() throws Exception {
		
		ArrayList<String> data = new ArrayList<String>();

		Scanner x= new Scanner(new File("object.txt"));
		String a;
		while(x.hasNext()) {
			a=x.nextLine();
			data.add(a);
		}
		x.close();
		return data;	
	}
	
	public void addFollower(String followerEmail, String followingEmail) throws SQLException {
		connect_func();
		String sql_T6_6 ="insert into  website.follow(followingemail,followeremail) values "
				+ "('"+followingEmail+"','"+followerEmail+"');";
		statement = connect.createStatement();
		statement.executeUpdate(sql_T6_6);
		disconnect();	   
	}
	
	public void removeFollower(String followerEmail, String followingEmail) throws SQLException {
		connect_func();
		String removeF ="Delete from website.follow where followingemail='"+followingEmail+"' and "
				+ "followeremail='"+followerEmail+"';";
		statement = connect.createStatement();
		statement.executeUpdate(removeF);		
	}
	
	public int getTOtalFollower(String email) throws SQLException {
		connect_func();
		String Q="SELECT * FROM website.users where email='"+email+"';";
		statement=connect.createStatement();
	    rs=statement.executeQuery(Q);
	    rs.next();
		return rs.getInt(7);
		
	}
	public int getTOtalFollowing(String Followeremail) throws SQLException {
		connect_func();
		String Q="SELECT * FROM website.users where email='"+Followeremail+"';";
		statement=connect.createStatement();
	    rs=statement.executeQuery(Q);
	    rs.next();
		return rs.getInt(8);
		
	}
	
	public ArrayList<String> getFollowerEmail(String Email) throws SQLException {
		connect_func(); 
		ArrayList<String> cars = new ArrayList<String>();
		String sql_q1="SELECT * FROM website.follow;";
		statement=connect.createStatement();
		ResultSet rs =statement.executeQuery(sql_q1);

		
		while(rs.next()) {
			if(Email.equals(rs.getString(2))) {
				cars.add(rs.getString(1));
			}
		}
		cars.add(Email);
		
		return cars;
		
	}
	
	public boolean inactiveUser(String email) throws SQLException {
		connect_func();
		String Qimage="SELECT count(*) as \"Number of Rows\" FROM website.images where postuser='"+email+"';";
		String Qfollowing="SELECT count(*) as \"Number of Rows\" FROM website.follow where followeremail='"+email+"';";
		String Qlike="SELECT count(*) as \"Number of Rows\" FROM website.likeimage where email='"+email+"';";
		String Qcomment="SELECT count(*) as \"Number of Rows\" FROM website.comments where email='"+email+"';";
		
		statement=connect.createStatement();
		//Getting number of rows in image
		ResultSet rs =statement.executeQuery(Qimage);
		rs.next();
		int img=rs.getInt(1);
		
		//Getting number of rows in following
		ResultSet rs2 =statement.executeQuery(Qfollowing);
		rs2.next();
		int follower=rs2.getInt(1);
		
		//getting number of rows in like
		ResultSet rs3 =statement.executeQuery(Qlike);
		rs3.next();
		int like=rs3.getInt(1);
		
		//getting number of rows in comment
		ResultSet rs4 =statement.executeQuery(Qcomment);
		rs4.next();
		int comment=rs4.getInt(1);
		
		int total=img+follower+like+comment;	
		if(total==0)
			return true;
		
		return false;
		
	}
	
	//returns how many images posted by users
	public int totalPostedImage(String email) throws SQLException {
		connect_func();
		int totalpost=0;
		String Qpost="SELECT count(*) as \"Number of Rows\" FROM website.images"
				+ " where postuser='"+email+"';";
		statement=connect.createStatement();
		ResultSet rs =statement.executeQuery(Qpost);
		rs.next();
		totalpost=rs.getInt(1);
		
		return totalpost;	
	}
	
	private int totalImagePostedByfollowers(String email) throws SQLException {
		connect_func();
		int sum=0;
		String Qfollow="SELECT * FROM website.follow where followeremail='"+email+"';";
		statement=connect.createStatement();
		ResultSet rs =statement.executeQuery(Qfollow);
		while(rs.next()) {
			sum+=totalPostedImage(rs.getString(1));
		}
		return sum;
		
	}
	
	public boolean positiveuser(String email) throws SQLException {
		connect_func();

		String Qpost="SELECT count(*) as \"Number of Rows\" FROM website.images "
				+ " where postuser='"+email+"';";
		String Qlike="SELECT count(*) as \"Number of Rows\" FROM website.likeimage where email "
				+ "='"+email+"';";
		ResultSet rs2 =statement.executeQuery(Qpost);
		rs2.next();
		int imgPostedByMe=rs2.getInt(1);
		
		ResultSet rs3 =statement.executeQuery(Qlike);
		rs3.next();
		int like=rs3.getInt(1);
		
		int totalImage=totalImagePostedByfollowers(email) +imgPostedByMe;
		if(totalImage==like && totalImage>0)
			return true;
		
		return false;		
	}
	public boolean topUser(String email) throws SQLException {
		connect_func();
		String Qpost="SELECT count(*) as \"Number of Rows\" FROM website.images"
				+ " where postuser='"+email+"';";
		statement=connect.createStatement();
		ResultSet rs =statement.executeQuery(Qpost);
		rs.next();
		int myimages=rs.getInt(1);
		if(myimages >0)
			return true;
		
		return false;
		
	}
	public boolean popularUser(String email) throws SQLException {
		connect_func();
		String Qfollower="SELECT * FROM website.users where email='"+email+"';";
		statement=connect.createStatement();
		ResultSet rs =statement.executeQuery(Qfollower);
		rs.next();
		int totalFollower=rs.getInt(7);
		if(totalFollower >= 5)
			return true;
		return false;
		
	}
	
	//-----------------poor images-----------------------
	private int getLikes(int id) throws SQLException {
		connect_func();
		String Qlike="SELECT count(*) as \"Number of Rows\" FROM website.likeimage where imageid="+id+";";
		statement=connect.createStatement();
		ResultSet rs3 =statement.executeQuery(Qlike);
		rs3.next();
		int like=rs3.getInt(1);
		return like; 
	}
	private int getComment(int id) throws SQLException {
		connect_func();
		String Qcomment="SELECT count(*) as \"Number of Rows\" FROM website.comments where imageid="+id+";";
		statement=connect.createStatement();
		ResultSet rs4 =statement.executeQuery(Qcomment);
		rs4.next();
		int comment=rs4.getInt(1);
		return comment;
	}
	public ArrayList<String> getPoorImages() throws SQLException{
		connect_func();
		ArrayList<String> Poor = new ArrayList<String>();
		String Qimage="SELECT * FROM website.images;";
		Statement statement2=connect.createStatement();
		ResultSet rs00 =statement2.executeQuery(Qimage);
		String a="";
		
		int total=0;
		while(rs00.next()) {
			total= getComment(rs00.getInt(1))+getLikes(rs00.getInt(1));
			if(total==0) {
				a="[ Username :"+rs00.getString(4)+" ] , [ Image post data and time:"+rs00.getString(6)+
						" ] , [ Image ID :"+rs00.getString(1)+" ]";
				Poor.add(a);
			}
		}
		return Poor;
	}
	//-----------------end-------------------
	
	// ------Top Tag--------------------
	private boolean topTag(String tag) throws SQLException {
		connect_func();
		String Qtag="SELECT count(*) as \"Number of Rows\" FROM website.imagetag where tag='"+tag+"';";
		statement=connect.createStatement();
		ResultSet rs3 =statement.executeQuery(Qtag);
		rs3.next();
		int sameTag=rs3.getInt(1);
		
		if(sameTag>= 3)
			return true;
		
		return false;
		
	}
	public ArrayList<String> getToTags() throws SQLException{
		connect_func();
	    String Qtag="SELECT * FROM website.imagetag;";
   	    ArrayList<String> TopTags = new ArrayList<String>();
   	    Statement statement2=connect.createStatement();
		ResultSet rs00 =statement2.executeQuery(Qtag);
		
		while(rs00.next()) {
			if(topTag(rs00.getString(2))) {
				TopTags.add(rs00.getString(2));
			}
		}
   	    
    	Set<String> set = new HashSet<>(TopTags);
    	TopTags.clear();
    	TopTags.addAll(set);
	
	    return TopTags;
	}
	//------------------END-----------------------------
	
	//------------VIRAL Image --------------------------
	    
	private int viralImage(int ID) throws SQLException {
		connect_func();
		String Qlikes="SELECT count(*) as \"Number of Rows\" FROM website.likeimage where "
				+ "imageid="+ID +" and LikedImages=1;";
		statement=connect.createStatement();
		rs =statement.executeQuery(Qlikes);
		rs.next();
		int totallikes=rs.getInt(1);
		
		return totallikes;
		
	}
	
	public ArrayList<String> getViralImages() throws SQLException{
		connect_func();
		ArrayList<String> Viral = new ArrayList<String>();
		ArrayList<String> Temp = new ArrayList<String>();
		Map<String, Integer> A = new HashMap<String, Integer>();
		
		String Qimage="SELECT * FROM website.images;";
		Statement statement2=connect.createStatement();
		ResultSet rs00 =statement2.executeQuery(Qimage);
		String a="";

		while (rs00.next()) {
			a="[ Username :"+rs00.getString(4)+" ] , [ Image post data and time :"+rs00.getString(6)+
					" ] , [ Image ID :"+rs00.getString(1)+" ] ,"
							+ " [ Total Likes :"+viralImage(rs00.getInt(1))+" ]";
			
			A.put(a, viralImage(rs00.getInt(1)));

		}
		 Map<String, Integer> sorted =  descendingSort(A);
		 copyIntoArray(sorted,Temp);
		 for(int i=0; i<Temp.size();i++) {
			 if(i <3) {
				 Viral.add(Temp.get(i));
			 }
		 }
		
		return Viral;
	}
	//---------------END--------------------------------
	
	//--------------cool Image--------------------------
	private boolean coolImage(int ID) throws SQLException {
		connect_func();
		String Qlikes="SELECT count(*) as \"Number of Rows\" FROM website.likeimage where "
				+ "imageid="+ID +" and LikedImages=1;";
		statement=connect.createStatement();
		rs =statement.executeQuery(Qlikes);
		rs.next();
		int totallikes=rs.getInt(1);
		if(totallikes>=5)
			return true;
		
		return false;
	}
	public ArrayList<String> getCoolImages() throws SQLException{
		connect_func();
		ArrayList<String> Cool = new ArrayList<String>();
		String Qimage="SELECT * FROM website.images;";
		Statement statement2=connect.createStatement();
		ResultSet rs00 =statement2.executeQuery(Qimage);
		String a="";
		
		while(rs00.next()) {
			if(coolImage(rs00.getInt(1))==true) {
				a="[ Username :"+rs00.getString(4)+" ] , [ Image post data and time:"+rs00.getString(6)+
						" ] , [ Image ID :"+rs00.getString(1)+" ]";
				Cool.add(a);
			}
		}
		return Cool;
	}
	
	//-------------New Images ---------------------------
	public ArrayList<Integer> getNewImages() throws SQLException {
		connect_func();
		
		ArrayList<Integer> NewImg = new ArrayList<Integer>();
		LocalDate localTime=java.time.LocalDate.now();
		String todaysDate=localTime.toString();
		String Qimage="SELECT * FROM website.images;";
		
		statement=connect.createStatement();
		rs =statement.executeQuery(Qimage);
		
		while(rs.next()) {
			if(rs.getString(5).equals(todaysDate)) {
				NewImg.add(rs.getInt(1));
			}
		}
		
		return NewImg;
		
	}
	//------------END---------------------
	public ArrayList<String> getALlUsernames() throws SQLException{
		connect_func();
		ArrayList<String> userList = new ArrayList<String>();
		String Quser="SELECT * FROM website.users;";
		statement=connect.createStatement();
		rs =statement.executeQuery(Quser);
		
		while(rs.next()) {
			userList.add(rs.getString(1));
		}
		return userList;
		
	}

	 public void disconnect() throws SQLException {
	        if (connect != null && !connect.isClosed()) {
	        	connect.close();
	        }
	}
	 
	 
	  public void connect_func() throws SQLException {
	        if (connect == null || connect.isClosed()) {
	            try {
	                Class.forName("com.mysql.jdbc.Driver");
	            } catch (ClassNotFoundException e) {
	                throw new SQLException(e);
	            }
	            connect =  DriverManager.getConnection(url, name, pass);
	    		        
	            System.out.println(connect);
	        }
	    }
	  private <K, V> void copyIntoArray(Map<K, V> map, ArrayList<String> array) {
	        for (Map.Entry<K, V> entry : map.entrySet()) {
	           array.add((String) entry.getKey());
	        }
	    }
	    private Map<String, Integer> descendingSort(Map<String, Integer> map) {

	    	  List<Map.Entry<String, Integer>> list = new LinkedList<Entry<String, Integer>>(map.entrySet());
	    	    Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {
	    	        @Override
	    	        public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
	    	            return o2.getValue().compareTo(o1.getValue());
	    	        }
	    	    });

	    	    Map<String, Integer> result = new LinkedHashMap<>();
	    	    for (Map.Entry<String, Integer> entry : list) {
	    	        result.put(entry.getKey(), entry.getValue());
	    	    }
	    	    return result;
	    }
	  	
}
