package controller;


import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import DAO.controllerDAO;
import JavaFile.NewUsers;
import java.sql.Connection;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.sql.ResultSet;

 
/**
 * ControllerServlet.java
 * This servlet acts as a page controller for the application, handling all
 * requests from the user.
 * @author Tapon Das
 */
@MultipartConfig
public class ControlServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private Connection connect = null;
	private Statement statement = null;
	private ResultSet rs=null;
	private String url="jdbc:mysql://localhost:3306/website";
	private String name="root";
	private String pass="root";
    
    private controllerDAO ok;
	public void init() {
		ok=new controllerDAO();
	}
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("doPost started: 000000000000000000000000000");
        doGet(request, response);
        System.out.println("doPost finished: 11111111111111111111111111");
    }
 
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("doGet started: 000000000000000000000000000"); 
     
        String action = request.getServletPath();
        System.out.println(action);
        try {
            switch (action) {
            case "/Search": 
                System.out.println("The action is: Search Username");
                Search(request, response);           	
                break;
            case "/Upload":
                System.out.println("The action is: Uplaod Image");
                Upload(request, response);
                break;
            case "/Likes":
                System.out.println("The action is: Like Image");
            	   Likes(request, response);
                break;
            case "/Dislikes":
                System.out.println("The action is: Dislike Image");
            	   Dislikes(request, response);
                break;
            case "/DeleteImg":
                System.out.println("The action is: Deleteimage");
                DeleteImg(request, response);
                break;
            case "/Comments":
                System.out.println("The action is: Comment on image");
                Comments(request, response);
                break;
            case "/Initialize":
                System.out.println("The action is: Initialize database");
                Initialize(request, response);
                break;
            case "/LogIn":
                System.out.println("The action is: Login ");
                LogIn(request, response);
                break;
            case "/SignUp":
                System.out.println("The action is: Sign Up");
                SignUp(request, response);
                break;
            case "/Editpicture":
                System.out.println("The action is: Edit picture (tag and Description)");
                Editpicture(request, response);
                break;
            case "/DeleteComment":
                System.out.println("The action is: Deleteing Comment");
                DeleteComment(request, response);
                break;
            case "/UpdateComment":
                System.out.println("The action is: Updating comment");
                UpdateComment(request, response);
                break;
            case "/Follow":
                System.out.println("The action is: Following user");
                Follow(request, response);
                break;
            case "/Unfollow":
                System.out.println("The action is: Unfollowing user");
                Unfollow(request, response);
                break;
            case "/PNuser":
                System.out.println("The action is:  userdetails");
                PNuser(request, response);
                break;
            case "/ImgTag":
                System.out.println("The action is:  Details of Image and Tags");
                ImgTag(request, response);
                break;
            case "/CommonUser":
                System.out.println("The action is:  Details of common User");
                CommonUser(request, response);
                break;
            default:
                System.out.println("Not sure which action, we will treat it as the list action");
                //listPeople(request, response);           	
                break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
        System.out.println("doGet finished: 111111111111111111111111111111111111");
    }
    private void CommonUser(HttpServletRequest request, HttpServletResponse response) {
    	String UserAemail = request.getParameter("UserA");
        String UserBemail = request.getParameter("UserB");
        ArrayList<String> commonUser = new ArrayList<String>();
        
        String intersection="select distinct a.followingemail from website.follow a, website.follow b\r\n"
        		+ "where a.followingemail = b.followingemail\r\n"
        		+ "and a.followeremail='"+UserAemail+"'\r\n"
        		+ "and b.followeremail='"+UserBemail+"';";
        try {
		    System.out.println("Select a table and then print out its content.");
		    Class.forName("com.mysql.jdbc.Driver"); 
		    connect = DriverManager.getConnection(url, name, pass);
		    statement = connect.createStatement();
		    rs=statement.executeQuery(intersection);
		    
		    while(rs.next()) {
		    	commonUser.add(rs.getString(1));
		    }
		    if(commonUser.size()==0) {
		    	commonUser.add("No Common Users.");
		    }
		    request.setAttribute("Com", "User A and B followed:");
			request.setAttribute("Common", commonUser);   
		    RequestDispatcher rd= request.getRequestDispatcher("Profile.jsp");
		    rd.forward(request, response);
			   	    		  	     
		  } catch (Exception e) {
		       System.out.println(e);
		  }
        
    }
   
    private void PNuser(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
    	String user="SELECT * FROM website.users;";
    	
    	ArrayList<String> InactiveUsers = new ArrayList<String>();
    	ArrayList<String> PositiveUsers = new ArrayList<String>();
    	ArrayList<String> TopUsers = new ArrayList<String>();
    	ArrayList<String> PopulerUser = new ArrayList<String>();
    	Map<String, Integer> A = new HashMap<String, Integer>();
    	

    	try {
		    System.out.println("Select a table and then print out its content.");
		    Class.forName("com.mysql.jdbc.Driver"); 
		    connect = DriverManager.getConnection(url, name, pass);
		    statement = connect.createStatement();
		    rs=statement.executeQuery(user);
		    while(rs.next()) {
		    	if(ok.inactiveUser(rs.getString(1))==true) {
		    		InactiveUsers.add("( "+rs.getString(1)+" )"+rs.getString(3)+" "+rs.getString(4));
		    	}
		    	if(ok.positiveuser(rs.getString(1))==true) {
		    		PositiveUsers.add("( "+rs.getString(1)+" )"+rs.getString(3)+" "+rs.getString(4));
		    	}
		    	if(ok.topUser(rs.getString(1))==true) {
		    		System.out.println("Checking what emails are going in here:"+rs.getString(1));
		    		
		    		A.put("( "+rs.getString(1)+" )"+rs.getString(3)+" "
		    	+rs.getString(4)+" :"+ok.totalPostedImage(rs.getString(1)),ok.totalPostedImage(rs.getString(1)));	    		
		    	}
		    	if(ok.popularUser(rs.getString(1))==true) {
		    		PopulerUser.add("( "+rs.getString(1)+" )"+rs.getString(3)
		    		+" "+rs.getString(4) +" :"+rs.getString(7));
		    		System.out.println("Popular user: "+rs.getString(1));
		    	}
		    }
		    Map<String, Integer> sorted =  descendingSort(A);
		    copyIntoArray(sorted,TopUsers);
		    
		    request.setAttribute("INA", "List of Inactive users:");
		    request.setAttribute("POS", "List of Positive users:");
		    request.setAttribute("TOP", "List of Top users:");
		    request.setAttribute("POP", "List of Popular users:");
		    request.setAttribute("Inactive", InactiveUsers);
		    request.setAttribute("Positive", PositiveUsers);
		    request.setAttribute("Topuser", TopUsers);
		    request.setAttribute("Populer", PopulerUser);
		    
			RequestDispatcher rd= request.getRequestDispatcher("Profile.jsp");
			rd.forward(request, response);
			   	    		  	     
		  } catch (Exception e) {
		       System.out.println(e);
		  }
    	
    }
    private void ImgTag(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
    		
    	ArrayList<String> PoorImages = ok.getPoorImages();
    	ArrayList<String> ViralImages = ok.getViralImages();
    	ArrayList<Integer> NewImages = ok.getNewImages();
    	ArrayList<String> CoolImages = ok.getCoolImages();
    	ArrayList<String> TopTags = ok.getToTags();
    	
    	request.setAttribute("Poor", "List of all poor images:");
		request.setAttribute("Vir", "List of Viral Images:");
		request.setAttribute("New", "List of New Images:");
		request.setAttribute("Cool", "List of cool Images");
		request.setAttribute("Top", "List of Top Tags:");
		    
		request.setAttribute("Poorimage", PoorImages);
		request.setAttribute("ViralImage", ViralImages);
		request.setAttribute("NewImages", NewImages);
		request.setAttribute("CoolImages", CoolImages);
	    request.setAttribute("TopTag", TopTags); 
		    
	    RequestDispatcher rd= request.getRequestDispatcher("Profile.jsp");
	    rd.forward(request, response);
   
    }
    private void Follow(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
    	
    	String followingemail=request.getParameter("following");
    	String updatefollowing="update  website.users set numoffollowing="+(ok.getTOtalFollowing(ok.getUsername())+1)
				+ " where email='"+ok.getUsername()+"';";
    	String updatefollower="update  website.users set numoffollowers="+(ok.getTOtalFollower(followingemail)+1)
				+ " where email='"+followingemail+"';";
    	
    	try {
		    System.out.println("Select a table and then print out its content.");
		    Class.forName("com.mysql.jdbc.Driver"); 
		    connect = DriverManager.getConnection(url, name, pass);
		    statement = connect.createStatement();
		    
		    ok.addFollower(ok.getUsername(), followingemail);
		    statement.executeUpdate(updatefollowing);
		    statement.executeUpdate(updatefollower);
		     
		    RequestDispatcher rd= request.getRequestDispatcher("Profile.jsp");
			rd.forward(request, response);
			   	    		  	     
		  } catch (Exception e) {
		       System.out.println(e);
		  }
    	
    }
    
    private void Unfollow(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
    	
    	String Unfollowingemail=request.getParameter("following");
    	String updatefollowing="update  website.users set numoffollowing="+(ok.getTOtalFollowing(ok.getUsername())-1)
				+ " where email='"+ok.getUsername()+"';";
    	String updatefollower="update  website.users set numoffollowers="+(ok.getTOtalFollower(Unfollowingemail)-1)
				+ " where email='"+Unfollowingemail+"';";
    	   	System.out.println("Unfolloing email:"+ Unfollowingemail+ ""
    	   			+ " following email: "+ok.getUsername());
    	try {
		    System.out.println("Select a table and then print out its content.");
		    Class.forName("com.mysql.jdbc.Driver"); 
		    connect = DriverManager.getConnection(url, name, pass);
		    statement = connect.createStatement();
		    
		    ok.removeFollower(ok.getUsername(), Unfollowingemail);
		    statement.executeUpdate(updatefollowing);
		    statement.executeUpdate(updatefollower);
		     
		    RequestDispatcher rd= request.getRequestDispatcher("Profile.jsp");
			rd.forward(request, response);
			   	    		  	     
		  } catch (Exception e) {
		       System.out.println(e);
		  }
    }
    
    private void UpdateComment(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
    	String newComment = request.getParameter("comment");
    	String fullDescription = ok.getFulldescription();
    	System.out.println("Testing full Description: "+fullDescription +" new comment :"+newComment);
    	String [] word=fullDescription.split("/7/");
    	String updateComment="update website.comments set description='"+newComment+"'"
				+ " where imageid="+Integer.parseInt(word[0])+" and email='"+word[1]+"' and "
						+ "description='"+word[2]+"'";
		try {
		    System.out.println("Select a table and then print out its content.");
		    Class.forName("com.mysql.jdbc.Driver"); 
		    connect = DriverManager.getConnection(url, name, pass);
		    statement = connect.createStatement();
		    statement.executeUpdate(updateComment);
		    
		    RequestDispatcher rd= request.getRequestDispatcher("Profile.jsp");
			rd.forward(request, response);
			   	    		  	     
		  } catch (Exception e) {
		       System.out.println(e);
		  }
    	
    }
    private void DeleteComment(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
    	
    	String imgID =request.getParameter("imgID");
    	String email=request.getParameter("Email");
    	String Description1=request.getParameter("Ddd");
    	System.out.println("Just checking: "+email+"  "+imgID+"  "+Description1);
    	String Q1="Delete from website.comments where email='"+email+ "'"
    			+ "and imageid="+Integer.parseInt(imgID) +" and description='"+
    			Description1+"';";
		
		try {
		    System.out.println("Select a table and then print out its content.");
		    Class.forName("com.mysql.jdbc.Driver"); 
		    connect = DriverManager.getConnection(url, name, pass);
		    statement = connect.createStatement();
		    statement.executeUpdate(Q1);
		   
		    RequestDispatcher rd= request.getRequestDispatcher("Profile.jsp");
			rd.forward(request, response);
			
			   	    		  	     
		  } catch (Exception e) {
		       System.out.println(e);
		  }
    }
    
    private void Editpicture(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
    	
    	String fromTextfile= request.getParameter("ID3");
    	String newtag= request.getParameter("newtag");
    	String newdescription= request.getParameter("comment");
    	String [] word =fromTextfile.split(",");
    	
		System.out.println("Testing a new description: "+newdescription+" New Tag:"+newtag);
		
		String updateTag="update website.imagetag set tag='"+newtag+"'"
				+ " where imageid="+Integer.parseInt(word[0])+" and tag='"+word[1]+"';";
		
		String updateDescription="update website.images set description='"+newdescription+"'"
				+ " where imageid="+Integer.parseInt(word[0])+" and postuser='"+word[2]+"';";
		
		
		try {
		    System.out.println("Select a table and then print out its content.");
		    Class.forName("com.mysql.jdbc.Driver"); 
		    connect = DriverManager.getConnection(url, name, pass);
		    statement = connect.createStatement();
		    
		    if(newtag.isEmpty() && !newdescription.isEmpty()) {
	    		//update description
		    	statement.executeUpdate(updateDescription);
	    	}
	    	else if(newdescription.isEmpty() && !newtag.isEmpty()) {
	    		//update image tag
	    		statement.executeUpdate(updateTag);
	    	}
	    	else if(!newdescription.isEmpty() && !newtag.isEmpty()) {
	    		//update both if they are not empty
	    		statement.executeUpdate(updateDescription);
	    		statement.executeUpdate(updateTag);
	    	}
	    	else {
	    		System.out.println("Nothing was entered");
	    	}
		    
		    RequestDispatcher rd= request.getRequestDispatcher("Profile.jsp");
			rd.forward(request, response);
			
			   	    		  	     
		  } catch (Exception e) {
		       System.out.println(e);
		  }
    }
    
    private void Initialize(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        System.out.println("listPeople started: 00000000000000000000000000000000000");
    	
    	String F_0 = "SET FOREIGN_KEY_CHECKS = 0;";
        String F_1 = "SET FOREIGN_KEY_CHECKS = 1;";

    	
    	String sql_T1_1 = "insert into  website.users(email,password, firstname,lastname,gender,"
    			+ "birthday,numoffollowers,numoffollowing) values "
                + "('hello@gmail.com', 'pass1234', 'Tom', 'Lui','M', '1990/12/20',1,4), " +
                "('hello2@gmail.com', 'pass1234', 'Lerry', 'Pal','F', '1980/12/20',5,1), " +
    			"('hello3@gmail.com', 'pass1234', 'Jerry', 'Ly','F', '1995/12/20',1,3),"+
                //Positive users
    			"('hello4@gmail.com', 'pass1234', 'Tom', 'Cat','M', '2000/07/20',1,2),"+	
     			"('hello5@gmail.com', 'pass1234', 'Jerry', 'Ly','F', '1996/12/20',6,1),"+
     			"('hello6@gmail.com', 'pass1234', 'Tom', 'Dog','M', '2000/07/20',0,1),"+
     			//Inactive users
     			"('hell7@gmail.com', 'pass1234', 'Tom', 'Cow','M', '1990/12/20',0,0), " +
     			"('hello8@gmail.com', 'pass1234', 'Jerry', 'TD','F', '1995/12/20',0,0),"+
     			"('hello9@gmail.com', 'pass1234', 'Raz', 'Re','M', '2000/07/20',0,0),"+
     			//poor image uploader
     			"('poorguy@gmail.com', 'pass1234', 'Poor', 'Guy','M', '2000/07/20',0,0),"+
     			"('hello10@gmail.com', 'pass1234', 'Musk', 'Cat','M', '2000/07/20',0,2);";
    			
    	
    	String sql_T2_2 = "insert into  website.images(url,description,postuser,postdate,posttime)values "
                + "('Images/cat.jpg', 'This is a cat picture','hello@gmail.com', CURDATE() ,CURTIME())," +
    			"('Images/dog.jpg', 'This is a dog picture','hello3@gmail.com', CURDATE() ,CURTIME()),"+
                "('Images/bird.jpg', 'This is a bird picture','hello4@gmail.com', CURDATE() ,CURTIME()),"+
    			
                "('Images/sunset.jpg', 'This is a sunset picture','hello2@gmail.com', CURDATE() ,CURTIME())," +
    			"('Images/sunset2.jpg', 'Beautiful sun set','hello3@gmail.com', CURDATE() ,CURTIME()),"+
                "('Images/beach.jpg', 'I like going to beach','hello4@gmail.com', CURDATE() ,CURTIME()),"+
    			
                "('Images/beach.jpg', 'Making sand house at beach is fun.','hello3@gmail.com', CURDATE() ,CURTIME()),"+
                "('Images/lagunabeach.jpg', 'Amazing picture','hello4@gmail.com', CURDATE() ,CURTIME()),"+
                "('Images/lagunabeach2.jpg', 'I like this place.','hello2@gmail.com', CURDATE() ,CURTIME())," +
    			"('Images/sunset2.jpg', 'Wow! We had good time at beach!','hello3@gmail.com', CURDATE() ,CURTIME()),"+
                "('Images/beach.jpg', 'We went to fishing after','hello@gmail.com', CURDATE() ,CURTIME()),"+
    			//Image by poorguy
                "('Images/beach.jpg', 'I went beach alone.','poorguy@gmail.com', CURDATE() ,CURTIME()),"+
                "('Images/lagunabeach2.jpg', 'I had good time there.','poorguy@gmail.com', CURDATE() ,CURTIME()),"+
                "('Images/sunset2.jpg', 'No comment. Totally Amazing!','poorguy@gmail.com', CURDATE() ,CURTIME());";
    	
    	String sql_T3_3 = "insert into  website.imagetag(imageid,tag)values "
                + "(1,'Cat'),"
                + "(2,'Dog'),"
                + "(3,'Bird'),"
                + "(4,'Sunset'),"
                + "(5,'Sunset'),"
                + "(6,'Beach'),"
                + "(7,'Beach'),"
                + "(8,'Beach'),"
                + "(9,'Beach'),"
                + "(10,'Sunset'),"
                + "(11,'Beach'),"
                + "(12,'Sea'),"
                + "(13,'Sea'),"
                + "(14,'Sea');";
          
    	
    	String sql_T4_4 = "insert into  website.comments(email,imageid,description)values "
                + "('hello@gmail.com', 2, 'I like Dog Picture.'),"
                + "('hello@gmail.com', 1, 'I like Cat Picture.'),"
                + "('hello4@gmail.com', 2, 'I have 3 pet dogs.');" ;
             	
    	String sql_T5_5 ="insert into  website.likeimage(email,imageid,clickedDate,LikedImages,UnlikedImages )values"
    			//positive user hello 4
    			+ "('hello4@gmail.com',3,CURDATE(),1,0),"
    			+ "('hello4@gmail.com',6,CURDATE(), 1, 0),"
    			+ "('hello4@gmail.com',8,CURDATE(),1,0),"
    			+ "('hello4@gmail.com',4,CURDATE(), 1, 0),"
    			+ "('hello4@gmail.com',9,CURDATE(),1,0),"
    			//positive user hello 3
    			+ "('hello3@gmail.com',1,CURDATE(),1,0),"
    			+ "('hello3@gmail.com',2,CURDATE(), 1, 0),"
    			+ "('hello3@gmail.com',4,CURDATE(),1,0),"
    			+ "('hello3@gmail.com',5,CURDATE(), 1, 0),"
    			+ "('hello3@gmail.com',7,CURDATE(),1,0),"
    			+ "('hello3@gmail.com',9,CURDATE(),1,0),"
    			+ "('hello3@gmail.com',10,CURDATE(), 1, 0),"
    			+ "('hello3@gmail.com',11,CURDATE(),1,0),"
    			
    			+ "('hello@gmail.com',4,CURDATE(),1,0),"
    			+ "('hello2@gmail.com',4,CURDATE(), 1, 0),"
    			+ "('hello5@gmail.com',4,CURDATE(),1,0);";
    	
    	
    	String sql_T6_6 ="insert into  website.follow(followingemail,followeremail) values "
    			+ "('hello4@gmail.com','hello@gmail.com'),"
    			+ "('hello3@gmail.com','hello@gmail.com'),"
    			+ "('hello@gmail.com','hello3@gmail.com'),"
    			
    			+ "('hello2@gmail.com','hello@gmail.com'),"
    			+ "('hello2@gmail.com','hello10@gmail.com'),"
    			+ "('hello2@gmail.com','hello3@gmail.com'),"
    			+ "('hello2@gmail.com','hello4@gmail.com'),"
    			+ "('hello2@gmail.com','hello5@gmail.com'),"
    			
    			+ "('hello5@gmail.com','hello@gmail.com'),"//0
    			+ "('hello5@gmail.com','hello2@gmail.com'),"
    			+ "('hello5@gmail.com','hello3@gmail.com'),"
    			+ "('hello5@gmail.com','hello4@gmail.com'),"
    			+ "('hello5@gmail.com','hello10@gmail.com'),"
    			+ "('hello5@gmail.com','hello6@gmail.com');";
    	
    	String sql_T1 = "DROP TABLE IF EXISTS USERS";
    	String sql_T2 = "DROP TABLE IF EXISTS IMAGES";
    	String sql_T3 = "DROP TABLE IF EXISTS IMAGETAG";
    	String sql_T4 = "DROP TABLE IF EXISTS COMMENTS";
    	String sql_T5 = "DROP TABLE IF EXISTS LIKEIMAGE";
    	String sql_T6 = "DROP TABLE IF EXISTS FOLLOW";
    	
    	
    	String t1 = "CREATE TABLE USERS (" +
    			" email VARCHAR(100) NOT NULL, " +
    			" password VARCHAR(20), " +
    			" firstname VARCHAR(50), " +
    			" lastname VARCHAR(50), " +
    			" gender CHAR(1), " +
    			" birthday DATE, " +
    			" numoffollowers int, " +
    			" numoffollowing int, " +
    			" PRIMARY KEY (email))";
    	//changed postuser to email
    	String t2 = "CREATE TABLE IMAGES (" +
    			" imageid MEDIUMINT NOT NULL AUTO_INCREMENT, " +
    			" url VARCHAR(250), " +
    			" description VARCHAR(100), " +
    			" postuser VARCHAR(100) NOT NULL, "+
    			" postdate DATE, " +
    			" posttime DATETIME, " +
    			" PRIMARY KEY (imageid), " +
    			" FOREIGN KEY (postuser) references Users(email))";
    	
    	String t3 = "CREATE TABLE IMAGETAG (" +
    			" imageid MEDIUMINT NOT NULL , " +
    			" tag VARCHAR(150) NOT NULL ," +
    			" PRIMARY KEY(imageid, tag), " +
    			" FOREIGN KEY (imageid) REFERENCES IMAGES(imageid) )";

    	
    	String t4 = "CREATE TABLE COMMENTS (" +
    			" email VARCHAR(100) NOT NULL, " +//from user
    			" imageid MEDIUMINT NOT NULL , " +
    			" description VARCHAR(500), " +
    			" FOREIGN KEY (email) REFERENCES USERS(email), " +
    			" FOREIGN KEY (imageid) REFERENCES IMAGES(imageid) )";

    	String t5 = "CREATE TABLE LIKEIMAGE (" +
    			" email VARCHAR(100) NOT NULL, " +//from user
    			" imageid MEDIUMINT NOT NULL , "+
    			" clickedDate DATE, " +
    			" LikedImages INT, " +
    			" UnlikedImages INT, " +
    			" PRIMARY KEY (email, imageid), " +
    			" FOREIGN KEY (email) REFERENCES USERS(email), " +
    			" FOREIGN KEY (imageid) REFERENCES IMAGES(imageid) )";

    	String t6 = "CREATE TABLE FOLLOW (" +
    			" followingemail VARCHAR(100) NOT NULL, " +
    			" followeremail VARCHAR(100) NOT NULL, " +
    			" PRIMARY KEY (followingemail, followeremail), "+
    			" FOREIGN KEY (followingemail) REFERENCES users(email), " +
    			" FOREIGN KEY (followeremail) REFERENCES users(email))";
    
		try {
		    System.out.println("Select a table and then print out its content.");
		    // This will load the MySQL driver, each DB has its own driver
		    // Class.forName("com.mysql.jdbc.Driver");
		    // Setup the connection with the DB
		    Class.forName("com.mysql.jdbc.Driver"); 
		    connect = DriverManager.getConnection(url, name, pass);

		    // Statements allow to issue SQL queries to the database
		    statement = connect.createStatement();
		    		    
		    //Drop Tables   
		    statement.executeUpdate(F_0);
		    statement.executeUpdate(sql_T6);
		    statement.executeUpdate(sql_T5);
		    statement.executeUpdate(sql_T4);
		    statement.executeUpdate(sql_T3);
		    statement.executeUpdate(sql_T2);
		    statement.executeUpdate(sql_T1);
		    statement.executeUpdate(F_1);
		   
		    //Create Tables
		    statement.executeUpdate(t1);
		    statement.executeUpdate(t2);
		    statement.executeUpdate(t3);
		    statement.executeUpdate(t4);
		    statement.executeUpdate(t5);
		    statement.executeUpdate(t6);
		    
		    //Insert Into the table	    
		    statement.executeUpdate(sql_T1_1);
		    statement.executeUpdate(sql_T2_2);
		    statement.executeUpdate(sql_T3_3);
		    statement.executeUpdate(sql_T4_4);
		    statement.executeUpdate(sql_T5_5);
		    statement.executeUpdate(sql_T6_6);
		    
		   
		     
		  } catch (Exception e) {
		       System.out.println(e);
		  } 
		
		request.setAttribute("confermation", "The database is initialized!");
		RequestDispatcher rd= request.getRequestDispatcher("Login.jsp");
		rd.forward(request, response);
     
        System.out.println("listPeople finished: 111111111111111111111111111111111111");
    }
    private void LogIn(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        System.out.println("listPeople started: 00000000000000000000000000000000000");
    	
		String Emailaddress = request.getParameter("username");
        String password = request.getParameter("password");
        
        NewUsers _user= new NewUsers();
        _user.setEmailaddress(Emailaddress);
        _user.setPassword(password);
        
        try {
			if(ok.isPasswordAndEmailCorrect(Emailaddress, password)) {
				ok.saveUsername(Emailaddress);
				response.sendRedirect("Profile.jsp");
			}
			else {
				request.setAttribute("Incorrect", "Username or Password is incorrect. Try again!");
				RequestDispatcher rd= request.getRequestDispatcher("Login.jsp");
				rd.forward(request, response);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
     
        System.out.println("listPeople finished: 111111111111111111111111111111111111");
    }
    private void SignUp(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        System.out.println("listPeople started: 00000000000000000000000000000000000");
        String Emailaddress = request.getParameter("email");
        String password = request.getParameter("password");
        String firstName = request.getParameter("firstname");
        String lastName = request.getParameter("lastname");
        String gender = request.getParameter("gender");
        String DOB = request.getParameter("birthday");
		
        System.out.print(DOB);
        NewUsers _user= new NewUsers();
        _user.setEmailaddress(Emailaddress);
        _user.setPassword(password);
        _user.setFirstName(firstName);
        _user.setLastName(lastName);
        _user.setGender(gender);
        _user.setDOB(DOB);
      
        
        NewUsers people = new NewUsers(Emailaddress,password,firstName,lastName,gender,DOB);
        //Testing DB
        System.out.println(_user.getEmailaddress()+"  "+_user.getPassword()+" "+_user.getLastName());
       
        try {
			if(ok.isUsernameExist(Emailaddress)) {
				
				request.setAttribute("sameEmail", "User name :"+Emailaddress +" is taken!");
				RequestDispatcher rd= request.getRequestDispatcher("NewAccount.jsp");
				rd.forward(request, response);
			}
			else {
				ok.registerAccount(people);
				ok.saveUsername(Emailaddress);
				response.sendRedirect("Profile.jsp");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
     
        System.out.println("listPeople finished: 111111111111111111111111111111111111");
    }
    
    private void Search(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
    	 	
        System.out.println("listPeople started: 00000000000000000000000000000000000");
       
        String search=(request.getParameter("search").replaceAll("\\s", "")).toLowerCase();
        
	
		try {
		    System.out.println("Select a table and then print out its content.");
		    Class.forName("com.mysql.jdbc.Driver"); 
		    connect = DriverManager.getConnection(url, name, pass);
		    statement = connect.createStatement();
		    
		    
		    String Q1 ="SELECT * FROM website.users;";
		    String w="";
		    rs=statement.executeQuery(Q1);
		    
		    File file = new File("object.txt");
		    FileWriter fw = new FileWriter(file);
		    PrintWriter pw = new PrintWriter(fw);
		    
		    boolean inserted=false;
		  		
			while(rs.next()) {
				w=((rs.getString(3)+rs.getString(4)).replaceAll("\\s", "")).toLowerCase();;
				
				if(w.equals(search) || (rs.getString(3).toLowerCase()).equals(search) 
						||(rs.getString(4).toLowerCase()).equals(search)) {
					pw.println(rs.getString(1) +"/"+rs.getString(3)+
					"/"+rs.getString(4) +"/"+rs.getString(5)+"/"+rs.getString(6));	
					inserted=true;
				}
			}
			pw.close();
			if(inserted==true) {
			RequestDispatcher rd= request.getRequestDispatcher("community.jsp");
			rd.forward(request, response);
			}
			else if(inserted==false) {
				request.setAttribute("fail", "Nothing is found. Try again!");
				RequestDispatcher rd= request.getRequestDispatcher("Profile.jsp");
				rd.forward(request, response);
			}
			 	    
		  } catch (Exception e) {
		       System.out.println(e);
		  } 
     
        System.out.println("listPeople finished: 111111111111111111111111111111111111");
    }
    
    private static String getSubmittedFileName(Part part) {
	    for (String cd : part.getHeader("content-disposition").split(";")) {
	        if (cd.trim().startsWith("filename")) {
	            String fileName = cd.substring(cd.indexOf('=') + 1).trim().replace("\"", "");
	            return fileName.substring(fileName.lastIndexOf('/') + 1).substring(fileName.lastIndexOf('\\') + 1); // MSIE fix.
	        }
	    }
	    return null;
	}
    private void  Upload(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	String ImageTag= request.getParameter("Tag");
		String ImageDescription = request.getParameter("description");
		Part file =request.getPart("filename");
		String ImageFileName=getSubmittedFileName(file);
		System.out.println("Testing if file is there: "+ImageFileName);
		String uploadPath="C:/Users/Tapon/Desktop/database-master/database-master/"
				+ "database/WebContent/Images/"+ImageFileName;	
		
		//Upload image into images folder
		try {
			FileOutputStream output = new FileOutputStream(uploadPath);
			InputStream input= file.getInputStream();
			
			byte [] image = new byte [input.available()];
			input.read(image);
			output.write(image);
			output.close();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
			
		try {
		    System.out.println("Select a table and then print out its content.");
		    Class.forName("com.mysql.jdbc.Driver"); 
		    connect = DriverManager.getConnection(url, name, pass);
		    statement = connect.createStatement();
		    int ID = 0;
		    
		    String username= ok.getUsername();

		    String sql_T2_2 = "insert into website.images (url,description,postuser,postdate,posttime)" +
	                  "values ('Images/"+ImageFileName+"','"+ImageDescription+"','"+username+"', CURDATE() , CURTIME())";
		    
		    statement.executeUpdate(sql_T2_2);
		    
		    try {
				ID = ok.getLastImageID("images");
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		    
		    String sql_T3_3 = "insert into  website.imagetag(imageid,tag)values"
		            + "('"+ID+"','"+ImageTag+"');";
		  	    
		    statement.executeUpdate(sql_T3_3);
		    
		    RequestDispatcher rd= request.getRequestDispatcher("Profile.jsp");
			rd.forward(request, response);
			
		    	    		     
		  } catch (Exception e) {
		       System.out.println(e);
		  } 
     
        System.out.println("showNewForm finished: 1111111111111111111111111111111");
    }
 
    // to present an update form to update an  existing Student
    private void Likes(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        System.out.println("showEditForm started: 000000000000000000000000000");
     
        String imageID = request.getParameter("ID");
		String username=ok.getUsername();
		
		System.out.print(imageID +" boga  "+username);
		
		
		String update="update website.likeimage set LikedImages=1,"
				+ " UnlikedImages=0 where imageid="+imageID+" and email='"+username+"';";
		
		String sql_T5_5 ="insert into  website.likeimage(email,imageid,clickedDate,LikedImages,UnlikedImages )values"
    			+ "('"+username+"',"+Integer.parseInt(imageID)+",CURDATE(), 1, 0);";
			
		try {
		    System.out.println("Select a table and then print out its content.");
		    Class.forName("com.mysql.jdbc.Driver"); 
		    connect = DriverManager.getConnection(url, name, pass);
		    statement = connect.createStatement();
		    
		    if(!ok.isItNewOrOldPicture(username,Integer.parseInt(imageID) )) {
		    	statement.executeUpdate(sql_T5_5);
		    	
		    }
		    else {
		    	
		    	statement.executeUpdate(update);
		    }
		    
		    RequestDispatcher rd= request.getRequestDispatcher("Profile.jsp");
			rd.forward(request, response);
			
		    	    	    	    		  	     
		  } catch (Exception e) {
		       System.out.println(e);
		  } 
     
        System.out.println("showEditForm finished: 1111111111111111111111111111");
    }
 
    // after the data of a people are inserted, this method will be called to insert the new people into the DB
    // 
    private void  Dislikes(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        System.out.println("insertPeople started: 000000000000000000000000000");
     
        String imageID = request.getParameter("ID2");
		String username=ok.getUsername();
		
		System.out.print(imageID +" boga  "+username);
		
		String update="update website.likeimage set LikedImages=0,"
				+ " UnlikedImages=1 where imageid="+imageID+" and email='"+username+"';";
		
		String sql_T5_5 ="insert into  website.likeimage(email,imageid,clickedDate,LikedImages,UnlikedImages )values"
    			+ "('"+username+"',"+Integer.parseInt(imageID)+",CURDATE(), 0, 1);";
			
		try {
		    System.out.println("Select a table and then print out its content.");
		    Class.forName("com.mysql.jdbc.Driver"); 
		    connect = DriverManager.getConnection(url, name, pass);
		    statement = connect.createStatement();
		    
		    if(!ok.isItNewOrOldPicture(username,Integer.parseInt(imageID) )) {
		    	statement.executeUpdate(sql_T5_5);
		    }
		    else {
		    	statement.executeUpdate(update);
		    }
		    
		    RequestDispatcher rd= request.getRequestDispatcher("Profile.jsp");
			rd.forward(request, response);
			
			   	    		  	     
		  } catch (Exception e) {
		       System.out.println(e);
		  }
     
        System.out.println("insertPeople finished: 11111111111111111111111111");   
    }
 
    private void DeleteImg(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        System.out.println("updatePeople started: 000000000000000000000000000");
     
        String F_0 = "SET FOREIGN_KEY_CHECKS = 0;";
	    String F_1 = "SET FOREIGN_KEY_CHECKS = 1;";
	    
		String imgid=request.getParameter("ID3");
		String deleteImg ="Delete from website.images where imageid="+Integer.parseInt(imgid);
		String deleteLike ="Delete from website.likeimage where imageid="+Integer.parseInt(imgid);
		String deleteComment ="Delete from website.comments where imageid="+Integer.parseInt(imgid);
		String deleteTag ="Delete from website.imagetag where imageid="+Integer.parseInt(imgid);
	
		try {
		    System.out.println("Select a table and then print out its content.");
		    Class.forName("com.mysql.jdbc.Driver"); 
		    connect = DriverManager.getConnection(url, name, pass);
		    statement = connect.createStatement();
		    
		    statement.executeUpdate(F_0);
			statement.executeUpdate(deleteImg);
			statement.executeUpdate(deleteLike);
			statement.executeUpdate(deleteComment);
			statement.executeUpdate(deleteTag);
			statement.executeUpdate(F_1);
			
			RequestDispatcher rd= request.getRequestDispatcher("Profile.jsp");
			rd.forward(request, response);
			
		
		    	    	    	    		  	     
		  } catch (Exception e) {
		       System.out.println(e);
		  }
     
        System.out.println("updatePeople finished: 1111111111111111111111111111111");
    }
 
    private void Comments(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        System.out.println("deletePeople started: 000000000000000000000000000");
     
        String imageID = request.getParameter("ID3");
		String username=ok.getUsername();
		String description=request.getParameter("comment");
		
		System.out.print(imageID +" boga  "+username);
		
		String sql_T4_4 = "insert into  website.comments(email,imageid,description)values "
    			+ "('"+username+"',"+Integer.parseInt(imageID)+",'"+description+"');";
			
		try {
		    System.out.println("Select a table and then print out its content.");
		    Class.forName("com.mysql.jdbc.Driver"); 
		    connect = DriverManager.getConnection(url, name, pass);
		    statement = connect.createStatement();
		    statement.executeUpdate(sql_T4_4);
		    
		    RequestDispatcher rd= request.getRequestDispatcher("Profile.jsp");
			rd.forward(request, response);
		    
		  } catch (Exception e) {
		       System.out.println(e);
		  } 
		 
		
        System.out.println("deletePeople finished: 1111111111111111111111111111111");
    }
    private <K, V> void copyIntoArray(Map<K, V> map, ArrayList<String> array) {
        for (Map.Entry<K, V> entry : map.entrySet()) {
           array.add((String) entry.getKey());
        }
    }
    private Map<String, Integer> descendingSort(Map<String, Integer> map) {

    	  List<Map.Entry<String, Integer>> list = new LinkedList<Entry<String, Integer>>(map.entrySet());
    	    Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {
    	        @Override
    	        public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
    	            return o2.getValue().compareTo(o1.getValue());
    	        }
    	    });

    	    Map<String, Integer> result = new LinkedHashMap<>();
    	    for (Map.Entry<String, Integer> entry : list) {
    	        result.put(entry.getKey(), entry.getValue());
    	    }
    	    return result;
    }
    
    
}