# Database Exercises

Group numer #13:
Name: Tapon Das 
Access id: Gn8632

Name: Abdul Rashid
Access ID: Gi7872

Link part 3: https://rumble.com/vfvjrp-database-project-part-3-demo.html